/*
                    Authored by Pintu Kumar
					Regd. no. : 20021
					Date : 07/05/2021
					                                                                                                                */

//////////////////////Package///////////////////////////////////
package main.server;
////////////////////////////////////////////////////////////////

//////////////////////Importing Libraries///////////////////////
import java.net.*;
import java.io.*;
import java.util.*;
////////////////////////////////////////////////////////////////

///////////////////////Class MultiServer////////////////////////
public class MultiServer 
{
	////////////////Main method of Multiserver//////////////////
	public static void main(String[] args) throws IOException
    {
        ServerSocket serverSocket = null;
        boolean listening = true;
        System.out.println("In Multiserver.........");
        try 
		{
            serverSocket = new ServerSocket(5000);
            while (listening)
			{
				new MultiServerThread(serverSocket.accept()).start();
			}
        } 
		catch (IOException e) 
		{
            System.err.println("Could not listen on port: 5000.");
            System.exit(-1);
        }
        serverSocket.close();
    }
	//////////////End of Main method of MultiServer//////////////
}
//////////////////End of Class MultiServer///////////////////////