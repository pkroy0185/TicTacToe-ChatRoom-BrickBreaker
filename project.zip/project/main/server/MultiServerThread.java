/*
                    Authored by Pintu Kumar
					Regd. no. : 20021
					Date : 07/05/2021
					                                                                                                                */

//////////////////////Package///////////////////////////////////
package main.server;
////////////////////////////////////////////////////////////////

//////////////////////Importing Libraries///////////////////////
import java.util.*;
import java.net.*;
import java.io.*;

import main.services.tictactoe.*;
import main.services.chatroom.*;
import main.services.brickbreaker.*;
////////////////////////////////////////////////////////////////

////////////////////Class MultiServerThread/////////////////////
public class MultiServerThread extends Thread
{
    private Socket socket = null;
	private Random rd;
    private int option;
	  
    ////CONSTRUCTOR////
	public MultiServerThread(Socket socket)
	{
		super("MultiServerThread");
		rd = new Random();
		this.socket = socket;
	}

	public void run()
	{
		System.out.println("New client with address : "+socket.getInetAddress());
		try
		{
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String inputLine;
			char temp;
			StringBuffer output = new StringBuffer();
			
			out.println("\t\tHello, You are now connected to Roy's Server.");
			out.println("\t\tThere are three services provided by this server i.e. Tic Tac Toe game, Chat Room service and Brick Breaker Game.");
			out.println("\t\tTic Tac Toe is two clients based application, Chat Room is multiple clients based application and Brick Breaker is single client based application.");
			out.println("\tSERVICES : \n");
			out.println("\t\t1 :  TIC TAC TOE\n\t\t2 :  CHAT ROOM\n\t\t3 :  BRICK BREAKER\n");
			out.println("Enter your option : \n-EOF-");
			out.flush();
			
			inputLine = in.readLine();
			option = Integer.parseInt(inputLine);
			switch(option)
			{
				case 1:
						new TicTacToeServer();
						break;
				case 2:
						new ChatServer();
						break;
				case 3:
						new BrickBreaker();
						break;
                default:
						out.println("\t\tNo such services exist.......\n\t\tPlease choose existing services in next run.......\n-EOF-");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				socket.close();
			}
			catch(Exception e)
			{
				System.out.println("Problem while closing socket..."+e);
			}
		}
	}
  
}
///////////////End of Class MultiServerThread////////////////////