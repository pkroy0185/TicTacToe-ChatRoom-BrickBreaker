/*
                    Authored by Pintu Kumar
					Regd. no. : 20021
					Date : 07/05/2021
					                                                                                                                */

//////////////////////Package///////////////////////////////////
package main.client;
////////////////////////////////////////////////////////////////

//////////////////////Importing Libraries///////////////////////
import java.net.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.lang.*;

import main.services.tictactoe.*;
import main.services.chatroom.*;
import main.services.brickbreaker.*;
import main.utility.*;
////////////////////////////////////////////////////////////////

/////////////////////////Class Client///////////////////////////
public class Client
{
	//////////////////Main method of Client/////////////////////
	public static void main(String args[ ]) throws Exception
	{
		String host = "localhost",keyboardInput,response;
		InetAddress server = InetAddress.getByName(host);
		Socket s = new Socket(server, 5000);
		BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
		PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()));
		int myChoice;   
		while(true)
		{  
			response = r.readLine();	
			if(response.equals("-EOF-"))
				break;	
			System.out.println(response);
		}
		keyboardInput = Validator1.getString("");
		out.println(keyboardInput);
		out.flush();
		myChoice = Integer.parseInt(keyboardInput);	
		switch(myChoice)
		{
			case 1:   
					TicTacToeClient.startGame();                        // Tic Tac Toe
					break;
			case 2:   
					ChatClient.startChatRoom();                         // ChatRoom
					break;
			case 3:
					break;
			default:
			        while(true)
					{  
						response = r.readLine();	
						if(response.equals("-EOF-"))
							break;	
						System.out.println(response);
					}
					break;
		}
			
	}
    ///////////////End of Main method of Client//////////////////
}
/////////////////////End of Class Client/////////////////////////