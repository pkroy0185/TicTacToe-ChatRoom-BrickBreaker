/*
                    Authored by Pintu Kumar
					Regd. no. : 20021
					Date : 07/05/2021
					                                                                                                                */

//////////////////////Package///////////////////////////////////
package main.services.brickbreaker;
////////////////////////////////////////////////////////////////

//////////////////////Importing Libraries///////////////////////
import java.awt.Color;
import javax.swing.JFrame;
////////////////////////////////////////////////////////////////

//////////////////////Class BrickBreaker////////////////////////
public class BrickBreaker
{
	////CONSTRUCTOR////
	public BrickBreaker() 
	{
		JFrame obj=new JFrame();
		Gameplay gamePlay = new Gameplay();		
		obj.setBounds(10, 10, 700, 600);
		obj.setTitle("Breakout Ball");		
		obj.setResizable(false);
		obj.setVisible(true);
		obj.add(gamePlay);
        obj.setVisible(true);
	}
}
///////////////////End of Class BrickBreaker////////////////////